/*
 * main.cpp
 *
 *  Created on: Feb 23, 2021
 *      Author: sjqsj
 */

volatile int* sw;
volatile int* led;
int main(){
	sw = (int*) 0x9010;
	led = (int*) 0x9000;
	while(1){
		*led = *sw;
	}
}



